#!/usr/bin/env python3
"""Header quadratic-merge fuzzer — Rank 4 target:
vendor/odin-http/http.odin:222 strings.concatenate({old, ", ", new}) on EVERY
duplicate header → total byte-copies quadratic in duplicate count.
server.odin:1573 max_token_size -= len(token) fires AFTER merge (rank 4 note).

Goal: measure TIME per request; if quadratic, larger duplicate counts take
superlinear time. Also watch memory growth on the server side via /proc.
"""
import socket, time, sys, os

HOST, PORT = "127.0.0.1", 18080

def send(payload: bytes, read_timeout=10) -> tuple:
    t0 = time.monotonic()
    try:
        s = socket.create_connection((HOST, PORT), timeout=2)
        s.sendall(payload)
        try: s.shutdown(socket.SHUT_WR)
        except OSError: pass
        s.settimeout(read_timeout)
        out = b""
        while True:
            d = s.recv(4096)
            if not d: break
            out += d
        s.close()
        return (time.monotonic()-t0, out)
    except Exception as e:
        return (time.monotonic()-t0, f"ERR {e}".encode())

# Baseline: single header
def req(dups: int) -> bytes:
    # Use a short header name so we can fit many under 8000 bytes
    # Each header: X:1\r\n = 5 bytes + \r\n on request line etc.
    # Header name "X" value single digit → "X: n\r\n" ≈ 5-6 bytes ⇒ ~1300 max under 8000
    lines = [b"X: %d" % (i % 10) for i in range(dups)]
    return (b"GET / HTTP/1.1\r\nHost: x\r\n"
            + b"\r\n".join(lines) + b"\r\n\r\n")

# Try increasing duplicate counts and see how the server responds / how slow
results = []
for dups in [10, 50, 100, 200, 400, 800, 1200, 1600, 2000]:
    payload = req(dups)
    if len(payload) > 8100:
        print(f"dups={dups} size={len(payload)} OVER 8000 — expect 431 anyway", flush=True)
    dt, resp = send(payload)
    code = resp.split(b" ", 2)[1] if b" " in resp else b"?"
    print(f"dups={dups:5d} size={len(payload):5d} time={dt*1000:7.1f}ms status={code.decode(errors='replace')}", flush=True)
    results.append((dups, len(payload), dt, code))

print("---")
# Quadratic fit: time should ~ N^2 if the merge is the hot path
for i in range(1, len(results)):
    n0, _, t0, _ = results[i-1]
    n1, _, t1, _ = results[i]
    if t0 > 0 and n1 > n0:
        ratio_t = t1 / t0
        ratio_n = n1 / n0
        print(f"  n x{ratio_n:.2f} -> t x{ratio_t:.2f} (quadratic would be x{ratio_n*ratio_n:.2f})")
