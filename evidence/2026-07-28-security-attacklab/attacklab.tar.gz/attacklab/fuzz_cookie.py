#!/usr/bin/env python3
"""Cookie parser fuzzer — Rank 1 target:
vendor/odin-http/cookie.odin:148 Max-Age parse_int no range check (F-001 pattern)
vendor/odin-http/cookie.odin:334 year up to 9999 into time.datetime_to_time
"""
import socket, random, sys, time, os, signal

HOST, PORT = "127.0.0.1", 18080
random.seed(0xC00C1E)

INTEREST = [
    b"=", b";", b",", b" ", b"\r\n", b"\r", b"\n", b"\x00",
    b"-", b"+",
    b"expires=Fri, 99 Jan 99999 99:99:99 GMT",
    b"expires=01-Jan-99999999999999999999 GMT",
    b"expires=Sun, 06 Nov 1994 08:49:37 GMT",
    b"expires=Sun, 06 Nov 1994 08:49:37 PST",
    b"expires=99-Jan-0000 99:99:99 GMT",
    b"Max-Age=99999999999999999999999999999999",
    b"Max-Age=-99999999999999999999999999999999",
    b"Max-Age=9223372036854775807",
    b"Max-Age=9223372036854775808",
    b"Max-Age=-9223372036854775808",
    b"Max-Age=18446744073709551615",
    b"Max-Age=abc", b"Max-Age=", b"Max-Age= ",
    b"Domain=.", b"Domain=..", b"Path=/../../",
    b"Path=\x00", b"Secure", b"Secure=", b"HttpOnly",
    b"SameSite=Strict", b"SameSite=st",
]

SEEDS = [
    b"a=b",
    b"a=b; expires=Sun, 06 Nov 1994 08:49:37 GMT",
    b"a=b; Max-Age=3600",
    b"a=b; Max-Age=3600; expires=Sun, 06 Nov 1994 08:49:37 GMT; Path=/; Domain=.x; Secure; HttpOnly; SameSite=Lax",
    b"=",
    b";",
    b"a=",
    b"=v",
    b"a=b; =d; e=",
    b"a=b; ;;;;",
    b"a",
    b"a=b; c",
    b"; ; ; ; ; ; ; ;",
    b"a=b;c=d;e=f;g=h",
    b"session=abc123",
]

def mutate(seed):
    b = bytearray(seed)
    for _ in range(random.randint(1, 6)):
        if not b: break
        op = random.random()
        if op < 0.4:
            i = random.randrange(len(b)+1); b[i:i] = random.choice(INTEREST)
        elif op < 0.65:
            i = random.randrange(len(b)); j = min(len(b), i + random.randint(1, 16)); del b[i:j]
        elif op < 0.85:
            i = random.randrange(len(b)); b[i] = random.randrange(256)
        else:
            # Insert digit run (parse_int overflow hunting)
            i = random.randrange(len(b)+1); b[i:i] = str(random.randint(0, 10**random.randint(1,25))).encode()
    return bytes(b)

def build_req(cookie: bytes) -> bytes:
    return (b"GET / HTTP/1.1\r\nHost: x\r\n"
            b"Cookie: " + cookie + b"\r\n"
            b"\r\n")

def send(payload: bytes) -> bool:
    try:
        s = socket.create_connection((HOST, PORT), timeout=2)
        s.sendall(payload)
        try: s.shutdown(socket.SHUT_WR)
        except OSError: pass
        s.settimeout(2)
        try:
            while s.recv(4096): pass
        except (socket.timeout, ConnectionResetError, BrokenPipeError): pass
        s.close()
        return True
    except OSError:
        return False

def alive() -> bool:
    try:
        s = socket.create_connection((HOST, PORT), timeout=1)
        s.close()
        return True
    except OSError:
        return False

n = int(sys.argv[1]) if len(sys.argv) > 1 else 5000
saved = 0
for i in range(n):
    ck = mutate(random.choice(SEEDS))
    if not send(build_req(ck)):
        time.sleep(0.2)
        if not alive():
            print(f"[DEAD] iter={i} cookie={ck[:200]!r}", flush=True)
            with open(f"/tmp/attacklab/corpus/cookie_crash_{i:06d}.bin","wb") as f:
                f.write(build_req(ck))
            saved += 1
            if saved >= 3:
                break
    if i % 1000 == 0:
        print(f"iter {i} alive={alive()}", flush=True)

print(f"done iters={i+1} crashes={saved}")
