#!/bin/bash
exec /tmp/attacklab/target/target_plain
